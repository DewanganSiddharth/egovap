library(shiny)
library(plotly)

#shiny app consists of client and server.
shinyApp(
  ui <- fluidPage(#data included here is shown at front end.
    selectInput("variable", "Select Efficiency: ",
                c("Payee Efficiency" = "Pe",
                  "Collection Efficiency" = "Ce")),#the drop down menu for selecting different efficiency.
   
    plotOutput("graphPlot",#th id to plot the graph.
               hover = hoverOpts(id = "plot_hover")),#this sends the coordinate information to the server.
    verbatimTextOutput("plot_hoverinfo")#id for hovering.
  
  ),
  #server used to compute different functions.
  server <- function(input, output) {
    
    output$graphPlot <-  renderPlot({#the output of graph variable is render at output$graphPlot.S
      
      
      
      
    
    library("maps")
    library("ggplot2")
    library("raster")
    library("rgdal")
    library("rgeos")
    library("dplyr")
    
    ### Get data
      #to get coordinates of india map
    india <- getData("GADM", country = "India", level = 1)
    
    #now selecting map of ap from india
    ap <- subset(india, NAME_1 == "Andhra Pradesh")
    
    
    map <- fortify(ap)
    
    #constructs map of ap using above coordinates 
    p <- ggplot() + coord_fixed() +
      xlab("") + ylab("")
    
    
    ### Draw a map with the colors assign
    
    Andhra <- p + geom_polygon(data=ap, aes(x=long, y=lat, group=group), 
                               colour="light green", fill="light green")
 
    
    #cleaning up the map by removing the grid and filling white color instead on the background.
    cleanup <- 
      theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), 
            panel.background = element_rect(fill = 'white', colour = 'white'), 
            axis.line = element_line(colour = "white"), legend.position="none",
            axis.ticks=element_blank(), axis.text.x=element_blank(),
            axis.text.y=element_blank())
  
    #merging the white background and map of ap  
    base_world <- Andhra + cleanup
    
  
    
      #cities = read.csv("pedata.csv")  # read csv file 
   
    
    #plotting the data point of ulb into the map
      map_data <- 
        base_world +
        geom_point(data=cities, 
                   aes(x=Longitude, y=Latitude, colour=get(input$variable)),size=5,
                    alpha=I(0.7)) + theme_bw() + labs(colour = "Range Of Values")
    
      
      output$plot_hoverinfo <- renderPrint({
        cat("ULB Information:\n")
        
        #the below code is used to create different lists for hovering data on the map.
        l <- c()
        for(i in cities$Longitude)
        {
          l <- c(l,round(i,1))  
        }
        m <- c()
        for(i in cities$Latitude)
        {
          m <- c(m,round(i,1))  
        }
        city <- c()
        for(i in cities$City)
        {
          city <- c(city,i)
        }
        payee <- c()
        for(i in cities$Pe)
        {
          payee <- c(payee,i)
        }
        collec <- c()
        for(i in cities$Ce)
        {
          collec <- c(collec,i)
        }
        for(i in 1:length(l))
        {
          #when the input data is equal to the map coordinates then it selects the ulb name.
          if(round(input$plot_hover$x,1) == l[i] && round(input$plot_hover$y,1) == m[i])
          {
            cat("City: ",city[i],"\n")
            if(input$variable == "Pe")
            cat("Pe: ",payee[i],"\n")
            else
              cat("Ce: ",collec[i])
          }
        }
        
        #if(isTRUE(input$plot_hover$x %in% round(cities$Longitude,1)))
         # str(input$plot_hover$x)
        
        
      })
      
      
      #printing the final map
      map_data
      
      
      
      
      
    })
     
    
     
   
     
   
    
    
    
    
  }
)